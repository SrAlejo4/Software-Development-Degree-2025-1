﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NominaHerencia
{
    public  interface Ifecha
    {
        int dia();

        int mes();

        int anio();
    }
}
